from setuptools import setup

setup(name = 'sliquantkit',
      version = '0.1',
      description = "Sida.Li's personal quant kit",
      author='Sida Li',
      author_email='szlsd123@163.com',
      license='MIT',
      packages=['sliquantkit'],
      zip_safe=False)
    